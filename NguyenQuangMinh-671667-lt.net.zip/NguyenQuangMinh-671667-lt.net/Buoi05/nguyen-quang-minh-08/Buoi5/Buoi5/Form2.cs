﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buoi5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát ?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) { Close(); }
        }

        string strCon = @"Data Source=M08;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlCon = null;

        DataSet ds = null;
        SqlDataAdapter adapter= null;
        private void MoKetNoi()
        { 
            if(sqlCon== null) sqlCon= new SqlConnection(strCon);
            if(sqlCon.State==ConnectionState.Closed) sqlCon.Open();
        }

        private void HienThiDanhSach()
        {
            MoKetNoi();
            string sql = "select * from tblSinhVien";
            adapter = new SqlDataAdapter(sql, sqlCon);
            SqlCommandBuilder builder= new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tblSinhVien");
            dgvHienThiDanhSach.DataSource = ds.Tables["tblSinhVien"]; 

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSach();
            //btnThem.Enabled= false;
            btnSua.Enabled= false;
            btnXoa.Enabled= false;
            grbTTCT.Enabled= false;
        }

        //tim kiem thao ma sv
        private void TkMaSV(string maSV)
        {
            MoKetNoi();

            string sql = "select * from tblSinhVien where MaSV='"+maSV+"' ";
            adapter = new SqlDataAdapter(sql, sqlCon);
            ds = new DataSet();
            adapter.Fill(ds, "tblTkMaSV");
            dgvHienThiDanhSach.DataSource = ds.Tables["tblTkMaSV"];
        }

        //tim kiem theo ten sv
        private void TkTenSV(string tenSV)
        {
            MoKetNoi();

            string sql = "select * from tblSinhVien where TenSV like '%"+tenSV+"%' ";
            adapter = new SqlDataAdapter(sql, sqlCon);
            ds = new DataSet();
            adapter.Fill(ds, "tblTkTenSV");
            dgvHienThiDanhSach.DataSource = ds.Tables["tblTkTenSV"];
        }
        private void btnTimKiem_Click(object sender, EventArgs e)
        {

            string maSV = txtTkMaSV.Text.Trim();
            string tenSV = txtTkTenSV.Text.Trim();
            if(txtTkMaSV.Text !=""&& txtTkTenSV.Text == "")
            {
                TkMaSV(maSV);
            }
            else if (txtTkMaSV.Text == "" && txtTkTenSV.Text != "")
            {
                TkTenSV(tenSV);
            }
            else if (txtTkMaSV.Text != "" && txtTkTenSV.Text != "")
            {
                TkMaSV(maSV);
            }
            else
            {
                MessageBox.Show("bạn chưa nhập thông tin cần tìm kiếm");
            }
        }
        int chucnang = 0;
        private void btnThem_Click(object sender, EventArgs e)
        {
            chucnang = 1;
            grbTTCT.Enabled= true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            chucnang=2;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if(chucnang==1) 
            {
                ThemTTSV();
            }
            else if (chucnang == 2)
            {
                SuaTTSV();
            }
        }

        //them tt sinh vien
        private void ThemTTSV()
        {
            MoKetNoi();

            DataRow row = ds.Tables["tblSinhVien"].NewRow();

            row["MaSV"]= txtMaSV.Text.Trim();
            row["TenSV"] = txtTenSV.Text.Trim();    
            if(radNam.Checked==true) 
            {
                row["GioiTinh"] = "Nam";
            }
            else if (radNu.Checked == true)
            {
                row["GioiTinh"] = "Nữ";
            }

            row["NgaySinh"] = dtpNgaySinh.Value.Day + "/" + dtpNgaySinh.Value.Month + "/" + dtpNgaySinh.Value.Year;
            row["QueQuan"] = txtQueQuan.Text.Trim();
            row["MaLop"]= txtMaLop.Text.Trim();

           // ds.Tables["tblSinhVien"].Rows.Add(row);
            int kq = adapter.Update(ds.Tables["tblSinhVien"]);

            //if(kq>0)
            //{
            //    MessageBox.Show("Them sinh vien thanh cong");
            //    HienThiDanhSach();
            //}
            //else
            //{
            //    MessageBox.Show("Them sinh vien khong thanh cong");
            //    HienThiDanhSach();
            //}
             MessageBox.Show("Them sinh vien thanh cong");
               HienThiDanhSach();
        }

        //sua tt sinh vien
        private void SuaTTSV()
        {

        }

        private void dgvHienThiDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
