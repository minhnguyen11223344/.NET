﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace From
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát ", "Hộp Thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Close();
            }
        }

        string strCon = @"Data Source=M08;Initial Catalog=SinhVien;Integrated Security=True";

        SqlConnection sqlCon = null;
        private void moKetNoi()
        {
            //kiem tra 
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }
        private void hienThiDanhSach_SinhVien()
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void TKmaSV(string maSV)
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien where MaSV = '"+maSV +"'";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string _maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();

        }

        private void TktenSV(string tenSV)
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien where TenSV like '%" + tenSV +"%'";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string maSV = reader.GetString(0).Trim();
                string _tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(_tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string maSV = txtTkMaSV.Text;
            string tenSV = txtTkTenSV.Text;

            if(maSV != "" && tenSV == "") 
            {
                TKmaSV(maSV);
            }
            else if(maSV == "" && tenSV != "")

            {
                TktenSV(tenSV);
            }
            else if(maSV != "" && tenSV != "")
            {
                TKmaSV(maSV);
            }
            else if(maSV == "" && tenSV == "")
            {

                MessageBox.Show("Bạn chưa nhập thông tin cần tìm kiếm ");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            hienThiDanhSach_SinhVien();
        }
    }
}
   
    
