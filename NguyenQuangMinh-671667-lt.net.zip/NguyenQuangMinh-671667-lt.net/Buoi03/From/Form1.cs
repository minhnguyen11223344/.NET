﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace From
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát ", "Hộp Thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Close();
            }
        }

        string strCon = @"Data Source=M08;Initial Catalog=SinhVien;Integrated Security=True";

        SqlConnection sqlCon = null;
        private void moKetNoi()
        {
            //kiem tra 
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }
        private void hienThiDanhSach_SinhVien()
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void TKmaSV(string maSV)
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien where MaSV = '"+maSV +"'";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string _maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();

        }

        private void TktenSV(string tenSV)
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from SinhVien where TenSV like N'%" + tenSV +"%'";

            //gan ke noi

            sqlCmd.Connection = sqlCon;
            //thuc thi truy van 

            SqlDataReader reader = sqlCmd.ExecuteReader();

            //tao trắng danh sách
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                string maSV = reader.GetString(0).Trim();
                string _tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaysinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                //tao mot dong moi

                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(_tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                //gan vao bang listView 
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string maSV = txtTkMaSV.Text;
            string tenSV = txtTkTenSV.Text;

            if(maSV != "" && tenSV == "") 
            {
                TKmaSV(maSV);
            }
            else if(maSV == "" && tenSV != "")

            {
                TktenSV(tenSV);
            }
            else if(maSV != "" && tenSV != "")
            {
                TKmaSV(maSV);
            }
            else if(maSV == "" && tenSV == "")
            {

                MessageBox.Show("Bạn chưa nhập thông tin cần tìm kiếm ");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            hienThiDanhSach_SinhVien();
            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");
            btnSua.Enabled= false;
            btnXoa.Enabled= false;
            groupBox4.Enabled = false;
        }

        int chucNang = 0;
        private void btnThem_Click(object sender, EventArgs e)
        {
            chucNang = 1;
            groupBox4.Enabled = true;
        }

        private void xoaform()
        {
            txtMaSV.Clear();
            txtMaLop.Clear();
            txtQueQuan.Clear();
            txtTenSV.Clear();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (chucNang == 1)
                themSinhVien();
            else if (chucNang == 2)
                suaSinhVien();
        }

        private void suaSinhVien()
        {
            try
            {
                //lay du lieu tu form
                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = "";
                if (cbGioiTinh.SelectedIndex == 0)
                    gioiTinh = "Nam";
                else if (cbGioiTinh.SelectedIndex == 1)
                    gioiTinh = "Nữ";
                string ngaySinh = dateTimePicker1.Value.Year + "-" + dateTimePicker1.Value.Month + "-" + dateTimePicker1.Value.Day;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                //MO KET NOI
                moKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "update SinhVien set MaSV='"+maSV+"', TenSV=N'"+tenSV+"', GioiTinh=N'"+gioiTinh+"', NgaySinh=convert(datetime, '"+ngaySinh+"'), QueQuan = N'"+queQuan+"', MaLop='"+maLop+"' where MaSV='"+maSV+"'";
                // sqlCmd.CommandText = "insert into SinhVien values('"+txtMaSV+"',N'"+txtTenSV+"',N'"+cbGioiTinh+"',convert(datetime, '"+da+"', N'"+txtQueQuan+"', '"+txtMaLop+"')";

                //gan vao ket noi
                sqlCmd.Connection = sqlCon;
                int kq = sqlCmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("sua thong tin thanh cong");
                    hienThiDanhSach_SinhVien();
                    groupBox4.Enabled = true;
                    xoaform();
                }
                else
                {
                    MessageBox.Show("sua thog tin that bai");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void themSinhVien()
        {
            try 
            {
                //lay du lieu tu form
                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = "";
                if (cbGioiTinh.SelectedIndex == 0)
                    gioiTinh = "Nam";
                else if (cbGioiTinh.SelectedIndex == 1)
                    gioiTinh = "Nữ";
                string ngaySinh = dateTimePicker1.Value.Year+"-"+dateTimePicker1.Value.Month+"-"+dateTimePicker1.Value.Day;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                //MO KET NOI
                moKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "insert into SinhVien values('"+maSV+"',N'"+tenSV+"',N'"+gioiTinh+"',convert(datetime, '"+ngaySinh+"',111), N'"+queQuan+"', '"+maLop+"')";
               // sqlCmd.CommandText = "insert into SinhVien values('"+txtMaSV+"',N'"+txtTenSV+"',N'"+cbGioiTinh+"',convert(datetime, '"+da+"', N'"+txtQueQuan+"', '"+txtMaLop+"')";

                //gan vao ket noi
                sqlCmd.Connection = sqlCon;
                int kq = sqlCmd.ExecuteNonQuery();
                if(kq>0)
                {
                    MessageBox.Show("them thanh cong");
                    hienThiDanhSach_SinhVien();
                    groupBox4.Enabled = true;
                    xoaform();
                }
                else 
                {
                    MessageBox.Show("them that bai");
                }
            }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
        }
        string maSVxoa = "";
        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSua.Enabled=true;
            groupBox4.Enabled=false;
            btnXoa.Enabled=true;
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            ListViewItem lvi = lsvDanhSach.SelectedItems[0];
            txtMaSV.Text = lvi.SubItems[0].Text.Trim();
            txtTenSV.Text = lvi.SubItems[1].Text.Trim();
            if (lvi.SubItems[2].Text.Trim()=="Nam")
                cbGioiTinh.SelectedIndex= 0;
            else
                cbGioiTinh.SelectedIndex= 1;
            string[] ns = lvi.SubItems[3].Text.Trim().Split('/');
            dateTimePicker1.Value = new DateTime(int.Parse(ns[2]), int.Parse(ns[0]), int.Parse(ns[1]));
            txtQueQuan.Text = lvi.SubItems[4].Text.Trim();
            txtMaLop.Text = lvi.SubItems[5].Text.Trim();
            maSVxoa = lvi.SubItems[0].Text.Trim() ;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            chucNang = 2;
            groupBox4.Enabled = true;
        }

        private void xoaSinhVien()
        {
            try
            {
                //lay du lieu tu form
                string maSV = txtMaSV.Text.Trim();
                string tenSV = txtTenSV.Text.Trim();
                string gioiTinh = "";
                if (cbGioiTinh.SelectedIndex == 0)
                    gioiTinh = "Nam";
                else if (cbGioiTinh.SelectedIndex == 1)
                    gioiTinh = "Nữ";
                string ngaySinh = dateTimePicker1.Value.Year + "-" + dateTimePicker1.Value.Month + "-" + dateTimePicker1.Value.Day;
                string queQuan = txtQueQuan.Text.Trim();
                string maLop = txtMaLop.Text.Trim();

                //MO KET NOI
                moKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "delete from SinhVien where MaSV = '"+maSVxoa+"'";
                //gan vao ket noi
                sqlCmd.Connection = sqlCon;
                int kq = sqlCmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("them thanh cong");
                    hienThiDanhSach_SinhVien();
                    groupBox4.Enabled = true;
                    xoaform();
                }
                else
                {
                    MessageBox.Show("them that bai");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("ban co muon xoa sinh vien nay khong", "hop thoai", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) 
            {
                xoaSinhVien();
            }
        }
    }
}
   
    
