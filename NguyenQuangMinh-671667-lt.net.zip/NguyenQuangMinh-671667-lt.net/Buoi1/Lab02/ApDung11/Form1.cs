﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result= MessageBox.Show("Bạn có thực sự muốn thoát không ?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if(result == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtNhapA.Text);
            int b = int.Parse(txtNhapB.Text);

            // buoc 2 phan chia truong hop
            try
            {
                if(radUSCLN.Checked==true) 
                {
                    txtKetQua.Text = TimUSCLN(a,b).ToString();
                }
                else if(radBSCNN.Checked==true) 
                {
                    txtKetQua.Text = TimBSCNN(a,b).ToString();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private int TimUSCLN(int a,int b)
        {
            int r = a % b;
            while(r != 0)
            {
                a = b;
                b=r;
                r = a % b;
            }
            return b;
        }

        private int TimBSCNN(int a, int b)
        {
            int bsc = TimUSCLN(a,b);
            return a*b/bsc;
        }
    }
}
