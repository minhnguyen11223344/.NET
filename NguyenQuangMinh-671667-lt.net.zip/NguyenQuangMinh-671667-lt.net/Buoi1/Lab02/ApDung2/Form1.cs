﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string pass;
        private void button1_Click(object sender, EventArgs e)
        {
            pass += "1";
            txtPass.Text = pass;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pass += "2";
            txtPass.Text = pass;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pass += "3";
            txtPass.Text = pass;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            pass += "4";
            txtPass.Text = pass;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pass += "5";
            txtPass.Text = pass;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pass += "6";
            txtPass.Text = pass;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            pass += "7";
            txtPass.Text = pass;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            pass += "8";
            txtPass.Text = pass;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            pass += "9";
            txtPass.Text = pass;
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            pass = "";
            txtPass.Clear();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
           if(txtPass.Text=="123" || txtPass.Text=="321" )
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Nguyen quang minh");
                lvi.SubItems.Add("18/10/2004");
                listKetqQua.Items.Add(lvi);
            } 
           else if(txtPass.Text == "1234")
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Minh Quang Nguyen");
                lvi.SubItems.Add("Chap nhan");
                listKetqQua.Items.Add(lvi);
            }  
           else
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Khong co thong tin");
                lvi.SubItems.Add("Khong Chap nhan");
                listKetqQua.Items.Add(lvi);
            }    
        }
    }
}
