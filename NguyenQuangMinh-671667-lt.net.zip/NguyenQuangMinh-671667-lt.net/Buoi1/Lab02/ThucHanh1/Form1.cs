﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThucHanh1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCong_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a + b;

                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("loi o day " + ex);
            }

        }
        private void btnTru_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a - b;

                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("loi o day " + ex.ToString());
            }
        }

        private void btnNhan_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a * b;

                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("loi o day ");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtNhapA.Clear();
            txtNhapB.Clear();
            txtKetQua.Clear();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ban co thuc su muon thoat khong", "hop thoai", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Close();
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);
                if(b!=0)
                {
                    int c = a / b;
                }
                else
                {
                    MessageBox.Show("mau so bang 0 vui long nhap lai");
                }

                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("loi o day ");
            }
        }
    }
}
