﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL_SinhVien
{
    public class database_connect
    {
        string conn = @"Data Source=M08;Initial Catalog=QLSV;Integrated Security=True";
        public SqlConnection sqlconn = null;

       
        public void moketnoi()
        {
            if (sqlconn == null) sqlconn= new SqlConnection(conn);  
            if(sqlconn.State==ConnectionState.Closed) sqlconn.Open();
        }
    }
   
}
