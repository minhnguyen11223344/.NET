﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_SinhVien;
namespace DAL_SinhVien
{
    public class SinhVien_Access
    {
        private List<SinhVien> doc_dulieu_sinhVien()
        {
            List<SinhVien> ds = new List<SinhVien>();
            database_connect database= new database_connect();
            database.moketnoi();

            //doi tuong truy van 
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = System.Data.CommandType.Text;
            sqlcmd.CommandText = "select * from SinhVien";

            sqlcmd.Connection = database.sqlconn;

            SqlDataReader reader= sqlcmd.ExecuteReader();   

            while(reader.Read())
            {
                string maSV = reader.GetString(0);
                string tenSV = reader.GetString(1);
                string gioiTinh = reader.GetString(2);
                DateTime ngaySinh = reader.GetDateTime(3);
                string queQuan = reader.GetString(4);
                string maLop = reader.GetString(5);
            }

         
            return ds;
        }
       

    }
}
