﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_SinhVien
{
    public class SinhVien_GUI
    {
        public string MaSV { get; set; }
        public string TenSV { get; set; }
        public string gioiTinh { get; set; }
        public string ngaySinh { get; set; }
        public string queQuan { get; set; }
        public string maLop { get; set; }
    }
}
