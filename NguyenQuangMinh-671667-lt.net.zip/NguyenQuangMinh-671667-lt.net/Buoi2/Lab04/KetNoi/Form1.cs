﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KetNoi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //ket noi database

        string strCon = @"Data Source=M08;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlCon = null;
        
        private void moKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        private void dongKetNoi()
        {
            if(sqlCon!=null && sqlCon.State==ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        private void btnKetNoi_Click(object sender, EventArgs e)
        {
            moKetNoi();
            MessageBox.Show("KET NOI THANH CONG!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            moKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select count(*) from SinhVien";

            //gui truy van du lieu trong csdl

            sqlCmd.Connection = sqlCon;

            int soluongSv = (int)sqlCmd.ExecuteScalar();

            MessageBox.Show("so luong sinh vien co trong co so du lieu la : " + soluongSv);
        }
    }
}
